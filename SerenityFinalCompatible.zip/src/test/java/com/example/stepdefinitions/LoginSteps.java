package com.example.stepdefinitions;

import com.example.pages.LoginPage;
import com.example.utils.ConfigReader;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class LoginSteps {

    LoginPage loginPage;

    @Given("User is on login page")
    public void user_on_login_page() {
        ConfigReader.load(System.getProperty("env", "dev"));
        loginPage.openAt(ConfigReader.get("url"));
    }

    @When("User enters credentials from config")
    public void user_enters_credentials() {
        loginPage.enterUsername(ConfigReader.get("username"));
        loginPage.enterPassword(ConfigReader.get("password"));
    }

    @Then("User clicks login button")
    public void user_clicks_login() {
        loginPage.clickLogin();
    }
}