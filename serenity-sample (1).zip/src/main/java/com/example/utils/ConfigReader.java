package com.example.utils;

import java.io.InputStream;
import java.util.Properties;

public class ConfigReader {
    private static Properties props = new Properties();
    private static String env;

    static {
        try {
            InputStream input = ConfigReader.class.getClassLoader().getResourceAsStream("environment.properties");
            props.load(input);
            env = props.getProperty("env", "dev");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String get(String key) {
        return props.getProperty(env + "." + key);
    }
}